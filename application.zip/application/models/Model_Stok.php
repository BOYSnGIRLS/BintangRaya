<?php
class Model_Barang extends CI_Model {
	public $stok; 

}