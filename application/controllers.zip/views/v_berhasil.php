<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>


<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <!-- <img src="images/icon/logo.png" alt="Bintang Raya"> -->
                                <h1>Sukses</h1><br>
                                <h3>Profil anda berhasil diubah</h3>

                            </a>
                        </div>
                        <div class="login-form">
                                <div class="form-group">
                                    <center><label>Silahkan login kembali <a href="<?php echo base_url(); ?>Login/Logout">Login</a></label></center>
                                       
                                </div>                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    